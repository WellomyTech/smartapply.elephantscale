 'use client'

export default function LinkedInCallback() {
  // Not in use
  return null
}
