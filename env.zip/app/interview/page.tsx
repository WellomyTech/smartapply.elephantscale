"use client";

import { useEffect, useRef, useState } from "react";
import Vapi, { type VapiMessage } from "@vapi-ai/web";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  RotateCcw,
  PhoneOff,
  Settings,
  Mic,
  MicOff,
  Video,
  VideoOff,
} from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

type Status = "idle" | "listening" | "thinking" | "speaking";

const PUBLIC_KEY = "4b3fb521-9ad5-439a-8224-cdb78e2e78e8";
const ASSISTANT_ID = "9295e1aa-6e41-4334-9dc4-030954c7274a";

type Line = {
  role: "AI Interviewer" | "You";
  message: string;
  timestamp: string;
  final: boolean;
};

/** Speaking indicator that analyzes the PROVIDED cam+mic stream (no extra getUserMedia) */
function useSpeakingIndicatorFromStream(stream: MediaStream | null, active: boolean) {
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    let mounted = true;

    const boot = async () => {
      if (!active || !stream || audioContextRef.current) return;

      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;

      const source = ctx.createMediaStreamSource(stream);
      source.connect(analyser);

      audioContextRef.current = ctx;
      analyserRef.current = analyser;
      sourceRef.current = source;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteFrequencyData(dataArray);
        const volume = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
        if (mounted) setIsUserSpeaking(volume > 10);
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();
    };

    boot();

    if (!active) setIsUserSpeaking(false);

    return () => {
      mounted = false;
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      if (sourceRef.current) {
        try { sourceRef.current.disconnect(); } catch {}
        sourceRef.current = null;
      }
      if (audioContextRef.current) {
        try { audioContextRef.current.close(); } catch {}
        audioContextRef.current = null;
      }
      analyserRef.current = null;
    };
  }, [stream, active]);

  return isUserSpeaking;
}

export default function InterviewVoiceDemo() {
  const [status, setStatus] = useState<Status>("idle");
  const [reportId, setReportId] = useState<number | null>(null);
  const [jobtitle, setJobTitle] = useState<string | null>(null);
  const [companyname, setCompanyName] = useState<string | null>(null);
  const [isAnimatingOut, setIsAnimatingOut] = useState(false);
  const [timer, setTimer] = useState(0);
  const [transcript, setTranscript] = useState<Line[]>([]);
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);

  const vapiRef = useRef<Vapi | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const transcriptWrapRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  // Speaking indicator uses the SAME stream
  const isUserSpeaking = useSpeakingIndicatorFromStream(videoStream, status === "listening");

  const myLabel = user?.name || user?.email?.split("@")[0] || "You";
  const roleLabel = (r: string): Line["role"] =>
    r === "assistant" ? "AI Interviewer" : "You";

  // ===== Transcript buffering (complete sentences only) =====
  const buffersRef = useRef<Record<Line["role"], string>>({
    "AI Interviewer": "",
    You: "",
  });
  const lastSeenRef = useRef<Record<Line["role"], string>>({
    "AI Interviewer": "",
    You: "",
  });
  const lastRoleRef = useRef<Line["role"] | null>(null);

  const stamp = () =>
    new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  const ensureSentenceEnd = (s: string) =>
    /[.?!…]"?$/.test(s.trim()) ? s.trim() : s.trim() + ".";

  const popCompleteSentences = (buffer: string) => {
    // Sentences ending with . ? ! … optionally followed by a closing quote
    const re = /(.+?[.?!…]+(?:["'”’])?)(?:\s+|$)/g;
    const completed: string[] = [];
    let lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(buffer)) !== null) {
      completed.push(m[1].trim());
      lastIndex = re.lastIndex;
    }
    return { completed, remainder: buffer.slice(lastIndex) };
  };

  const pushLine = (role: Line["role"], text: string) => {
    setTranscript((prev) => [
      ...prev,
      { role, message: text, timestamp: stamp(), final: true },
    ]);
  };

  const flushBuffer = (role: Line["role"], force = false) => {
    const current = buffersRef.current[role] || "";
    if (!current.trim()) return;
    const { completed, remainder } = popCompleteSentences(current);
    completed.forEach((s) => pushLine(role, s));
    if (force && remainder.trim()) {
      pushLine(role, ensureSentenceEnd(remainder));
      buffersRef.current[role] = "";
    } else {
      buffersRef.current[role] = remainder;
    }
  };

  const resetBuffers = () => {
    buffersRef.current = { "AI Interviewer": "", You: "" };
    lastSeenRef.current = { "AI Interviewer": "", You: "" };
    lastRoleRef.current = null;
  };

  // ===== Effects =====
  useEffect(() => {
    // Load report_id as number
    const ridRaw = localStorage.getItem("report_id");
    const ridNum = ridRaw !== null ? Number(ridRaw) : null;
    setReportId(ridNum !== null && Number.isFinite(ridNum) ? ridNum : null);

    setJobTitle(localStorage.getItem("job_title"));
    setCompanyName(localStorage.getItem("company_name"));

    const vapi = new Vapi(PUBLIC_KEY);
    vapiRef.current = vapi;

    vapi.on("call-start", () => setStatus("listening"));
    vapi.on("speech-start", () => setStatus("speaking"));
    vapi.on("speech-end", () => {
      // AI finished talking → flush remaining AI buffer
      flushBuffer("AI Interviewer", true);
      setStatus("thinking");
    });
    vapi.on("call-end", () => {
      // Final flush for both speakers
      flushBuffer("AI Interviewer", true);
      flushBuffer("You", true);
      setStatus("idle");
      stopCamera();
    });

    // Build transcript: buffer partials and only show complete sentences
    vapi.on("message", (m: VapiMessage) => {
      if (m.type !== "transcript") return;
      const role = roleLabel(m.role);
      const fullText = (m as any).transcript ?? "";

      // Speaker switch → flush previous role's remainder
      if (lastRoleRef.current && lastRoleRef.current !== role) {
        flushBuffer(lastRoleRef.current, true);
      }
      lastRoleRef.current = role;

      const lastSeen = lastSeenRef.current[role] || "";
      const delta =
        fullText && fullText.startsWith(lastSeen)
          ? fullText.slice(lastSeen.length)
          : fullText; // robust if backend resets the string
      lastSeenRef.current[role] = fullText;

      buffersRef.current[role] += delta;
      flushBuffer(role, false); // emit only completed sentences
    });

    return () => {
      try { vapi.stop(); } catch {}
    };
  }, []);

  // Timer
  useEffect(() => {
    if (status !== "idle") {
      timerRef.current = setInterval(() => setTimer((p) => p + 1), 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setTimer(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [status]);

  // Auto-scroll transcript
  useEffect(() => {
    const el = transcriptWrapRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [transcript]);

  // Keep video element bound to stream
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (videoStream && !isVideoOff) {
      if (v.srcObject !== videoStream) v.srcObject = videoStream;
      queueMicrotask(() => v.play().catch(() => {}));
    } else {
      v.srcObject = null;
    }
  }, [videoStream, isVideoOff]);

  // ===== Media controls =====
  const attachVideoToElement = async (stream: MediaStream) => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = true; // autoplay policy
    v.playsInline = true;
    v.srcObject = stream;
    try {
      await v.play();
    } catch {
      // retry next frame (helps WebKit)
      await new Promise((r) => requestAnimationFrame(r));
      try { await v.play(); } catch {}
    }
  };

  const startCamera = async () => {
    // Single unified call for cam + mic
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: true,
      video: {
        width:  { ideal: 1280 },
        height: { ideal: 720  },
        facingMode: "user", // front cam on mobile; ignored on desktop
      },
    });

    // Ensure tracks are enabled
    stream.getVideoTracks().forEach((t) => (t.enabled = true));
    stream.getAudioTracks().forEach((t) => (t.enabled = true));

    setIsVideoOff(false);
    setIsMuted(false);
    setVideoStream(stream);

    await attachVideoToElement(stream);
    return stream;
  };

  const stopCamera = () => {
    if (videoStream) {
      videoStream.getTracks().forEach((t) => t.stop());
      setVideoStream(null);
    }
    const v = videoRef.current;
    if (v) v.srcObject = null;
  };

  // ===== Call lifecycle =====
  const handleStart = async () => {
    if (!vapiRef.current) return;
    setIsAnimatingOut(false);
    setTranscript([]);
    resetBuffers();
    setIsVideoOff(false);

    try {
      const stream = await startCamera(); // user gesture → attach + play video immediately
      // small guard for re-render timing
      setTimeout(() => { attachVideoToElement(stream); }, 100);

      await vapiRef.current.start(ASSISTANT_ID, {
        variableValues: {
          report_id: reportId as number,
          company_name: companyname ?? undefined,
          job_title: jobtitle ?? undefined,
        },
      });
    } catch (e) {
      console.error(e);
    }
  };

  const handleEnd = () => {
    if (!vapiRef.current) return;
    setIsAnimatingOut(true);
    vapiRef.current.stop();
    flushBuffer("AI Interviewer", true);
    flushBuffer("You", true);
    stopCamera();
    setTimeout(() => {
      setStatus("idle");
      setIsAnimatingOut(false);
    }, 250);
  };

  const handleRestart = () => {
    handleEnd();
    setTimeout(() => handleStart(), 600);
  };

  const toggleMute = () => {
    if (!videoStream) return;
    const track = videoStream.getAudioTracks()[0];
    if (!track) return;
    track.enabled = !track.enabled;
    setIsMuted(!isMuted);
  };

  const toggleVideo = () => {
    if (!videoStream) return;
    const track = videoStream.getVideoTracks()[0];
    if (!track) return;
    track.enabled = !track.enabled;
    setIsVideoOff(!isVideoOff);
  };

  const agentSpeaking = status === "speaking";
  const agentListening = status === "listening";
  const agentThinking = status === "thinking";

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  const getUserInitial = () =>
    user?.email ? user.email.charAt(0).toUpperCase() : "U";

  // ===== Render =====
  return (
    <main className="h-[100svh] bg-gradient-to-br from-primary/80 via-primary to-primary/80 flex flex-col">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-sm border-b border-white/10 px-4 py-3">
        <div className="max-w-7xl mx-auto flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-semibold text-white">AI Interview</h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-black/30 px-3 py-1.5 rounded-lg text-sm font-medium text-white/90 border border-white/20">
              Meeting ID: {reportId != null ? String(reportId) : "—"}
            </div>
            {status !== "idle" && (
              <div className="bg-red-500/20 px-3 py-1.5 rounded-lg text-sm font-medium text-red-200 border border-red-400/30 flex items-center gap-2">
                <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse" />
                LIVE {formatTime(timer)}
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="flex-1 min-h-0 flex">
        {status === "idle" ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6">
            <div className="text-center mb-8 max-w-2xl">
              <h2 className="text-3xl font-semibold text-white mb-4">
                Ready to Begin Your Interview?
              </h2>
              <p className="text-lg font-medium text-white/80">
                Start your professional AI-powered interview session when you're
                ready.
              </p>
            </div>
            <Button
              onClick={handleStart}
              disabled={!reportId}
              size="lg"
              className="text-white px-8 py-3 text-base font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
            >
              Start Interview
            </Button>
            {!reportId && (
              <p className="text-sm font-medium text-red-300 mt-4">
                Please ensure you have a valid report ID to start the interview.
              </p>
            )}
          </div>
        ) : (
          // Live layout
          <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
            {/* Video panel */}
            <div className="relative flex-1 p-2 sm:p-4 order-1 min-h-0">
              <div
                className={`relative w-full h-[calc(100svh-160px)] sm:h-auto sm:aspect-video bg-gray-900 rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 ${
                  isUserSpeaking ? "ring-4 ring-green-400 shadow-green-400/20" : ""
                }`}
              >
                {videoStream && !isVideoOff ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    muted
                    playsInline
                    disablePictureInPicture
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gray-800">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-gray-600 rounded-full flex items-center justify-center mb-3 mx-auto">
                        <span className="text-2xl text-white">{getUserInitial()}</span>
                      </div>
                      <p className="text-white text-sm font-medium">Camera Off</p>
                    </div>
                  </div>
                )}

                {/* user label */}
                <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm px-3 py-1.5 rounded-lg">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-medium select-none">{myLabel}</span>
                    {isUserSpeaking && (
                      <div className="flex gap-1">
                        <div className="w-1 h-3 bg-green-400 rounded-full animate-pulse" />
                        <div className="w-1 h-2 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: "0.1s" }} />
                        <div className="w-1 h-4 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }} />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Controls – fixed so they’re always reachable */}
              <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50">
                <div className="bg-black/50 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2 sm:gap-4 shadow-xl">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleMute}
                    className={`rounded-full w-10 h-10 p-0 transition-colors ${
                      isMuted ? "bg-red-500 hover:bg-red-600 text-white" : "bg-white/20 hover:bg-white/30 text-white"
                    }`}
                  >
                    {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleVideo}
                    className={`rounded-full w-10 h-10 p-0 transition-colors ${
                      isVideoOff ? "bg-red-500 hover:bg-red-600 text-white" : "bg-white/20 hover:bg-white/30 text-white"
                    }`}
                  >
                    {isVideoOff ? <VideoOff className="h-4 w-4" /> : <Video className="h-4 w-4" />}
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleRestart}
                    className="rounded-full w-10 h-10 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </Button>

                  <Button variant="destructive" size="sm" onClick={handleEnd} className="rounded-full w-10 h-10 p-0">
                    <PhoneOff className="h-4 w-4" />
                  </Button>

                  <Sheet>
                    <SheetTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full w-10 h-10 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                    </SheetTrigger>
                    <SheetContent className="bg-white">
                      <SheetHeader>
                        <SheetTitle className="font-semibold text-gray-900">Session Information</SheetTitle>
                      </SheetHeader>
                      <div className="mt-6 space-y-4">
                        <div>
                          <label className="text-sm font-semibold text-gray-700">Report ID</label>
                          <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
                            {reportId != null ? String(reportId) : "Not set"}
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-semibold text-gray-700">Job Title</label>
                          <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
                            {jobtitle || "Not set"}
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-semibold text-gray-700">Company</label>
                          <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
                            {companyname || "Not set"}
                          </p>
                        </div>
                      </div>
                    </SheetContent>
                  </Sheet>
                </div>
              </div>
            </div>

            {/* Transcript panel */}
            <div className="w-full lg:w-80 bg-white/95 backdrop-blur-sm border-t lg:border-t-0 lg:border-l border-white/20 flex flex-col order-2 min-h-0">
              <div className="p-4 border-b border-gray-200 sticky top-0 bg-white/95 z-10">
                <h3 className="font-semibold text-gray-900">Live Transcript</h3>
                <p className="text-sm text-gray-600 mt-1">Real-time conversation transcript</p>
              </div>

              <div
                ref={transcriptWrapRef}
                className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[unset] min-h-0"
              >
                {transcript.map((entry, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900 text-sm">{entry.role}</span>
                      <span className="text-xs text-gray-500">{entry.timestamp}</span>
                    </div>
                    <div
                      className={`p-3 rounded-lg text-sm ${
                        entry.role === "AI Interviewer" ? "bg-blue-50 text-blue-900" : "bg-gray-50 text-gray-900"
                      }`}
                    >
                      {entry.message}
                    </div>
                  </div>
                ))}
                {transcript.length === 0 && (
                  <div className="text-center text-gray-500 mt-8">
                    <p className="text-sm">Transcript will appear here once the conversation starts...</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}





// "use client";

// import { useEffect, useRef, useState } from "react";
// import Vapi, { type VapiMessage } from "@vapi-ai/web";
// import { Button } from "@/components/ui/button";
// import {
//   Sheet,
//   SheetContent,
//   SheetHeader,
//   SheetTitle,
//   SheetTrigger,
// } from "@/components/ui/sheet";
// import {
//   RotateCcw,
//   PhoneOff,
//   Settings,
//   Mic,
//   MicOff,
//   Video,
//   VideoOff,
// } from "lucide-react";
// import { useAuth } from "@/components/AuthProvider";

// type Status = "idle" | "listening" | "thinking" | "speaking";

// const PUBLIC_KEY = "4b3fb521-9ad5-439a-8224-cdb78e2e78e8";
// const ASSISTANT_ID = "9295e1aa-6e41-4334-9dc4-030954c7274a";

// type Line = {
//   role: "AI Interviewer" | "You";
//   message: string;
//   timestamp: string;
//   final: boolean;
// };

// function usePersistentSpeakingIndicator(active: boolean) {
//   const [isUserSpeaking, setIsUserSpeaking] = useState(false);
//   const audioContextRef = useRef<AudioContext | null>(null);
//   const analyserRef = useRef<AnalyserNode | null>(null);
//   const rafRef = useRef<number | null>(null);
//   const streamRef = useRef<MediaStream | null>(null);

//   useEffect(() => {
//     let isMounted = true;

//     if (active && !audioContextRef.current) {
//       navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
//         streamRef.current = stream;
//         const ctx = new (window.AudioContext ||
//           (window as any).webkitAudioContext)();
//         audioContextRef.current = ctx;
//         const source = ctx.createMediaStreamSource(stream);
//         const analyser = ctx.createAnalyser();
//         analyser.fftSize = 512;
//         source.connect(analyser);
//         analyserRef.current = analyser;
//         const dataArray = new Uint8Array(analyser.frequencyBinCount);

//         const detect = () => {
//           analyser.getByteFrequencyData(dataArray);
//           const volume =
//             dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
//           if (isMounted) {
//             const isSpeaking = volume > 10;
//             setIsUserSpeaking(isSpeaking);
//           }
//           rafRef.current = requestAnimationFrame(detect);
//         };
//         detect();
//       });
//     }

//     if (!active) setIsUserSpeaking(false);

//     return () => {
//       isMounted = false;
//       if (audioContextRef.current) {
//         audioContextRef.current.close();
//         audioContextRef.current = null;
//       }
//       if (streamRef.current) {
//         streamRef.current.getTracks().forEach((t) => t.stop());
//         streamRef.current = null;
//       }
//       if (rafRef.current !== null) {
//         cancelAnimationFrame(rafRef.current);
//       }
//     };
//   }, [active]);

//   return isUserSpeaking;
// }

// export default function InterviewVoiceDemo() {
//   const [status, setStatus] = useState<Status>("idle");
//   const [reportId, setReportId] = useState<number | null>(null); // number, not string
//   const [jobtitle, setJobTitle] = useState<string | null>(null);
//   const [companyname, setCompanyName] = useState<string | null>(null);
//   const [isAnimatingOut, setIsAnimatingOut] = useState(false);
//   const [timer, setTimer] = useState(0);
//   const [transcript, setTranscript] = useState<Line[]>([]);
//   const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
//   const [isMuted, setIsMuted] = useState(false);
//   const [isVideoOff, setIsVideoOff] = useState(false);

//   const vapiRef = useRef<Vapi | null>(null);
//   const timerRef = useRef<NodeJS.Timeout | null>(null);
//   const videoRef = useRef<HTMLVideoElement>(null);
//   const transcriptWrapRef = useRef<HTMLDivElement>(null);
//   const { user } = useAuth();
//   const isUserSpeaking = usePersistentSpeakingIndicator(status === "listening");

//   const myLabel = user?.name || user?.email?.split("@")[0] || "You";
//   const roleLabel = (r: string): Line["role"] =>
//     r === "assistant" ? "AI Interviewer" : "You";

//   // ===== Transcript buffering (complete sentences only) =====
//   const buffersRef = useRef<Record<Line["role"], string>>({
//     "AI Interviewer": "",
//     You: "",
//   });
//   const lastSeenRef = useRef<Record<Line["role"], string>>({
//     "AI Interviewer": "",
//     You: "",
//   });
//   const lastRoleRef = useRef<Line["role"] | null>(null);

//   const stamp = () =>
//     new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

//   const ensureSentenceEnd = (s: string) =>
//     /[.?!…]"?$/.test(s.trim()) ? s.trim() : s.trim() + ".";

//   const popCompleteSentences = (buffer: string) => {
//     // Captures sentences that end with . ? ! … possibly followed by a quote
//     const re = /(.+?[.?!…]+(?:["'”’])?)(?:\s+|$)/g;
//     const completed: string[] = [];
//     let lastIndex = 0;
//     let m: RegExpExecArray | null;
//     while ((m = re.exec(buffer)) !== null) {
//       completed.push(m[1].trim());
//       lastIndex = re.lastIndex;
//     }
//     return { completed, remainder: buffer.slice(lastIndex) };
//   };

//   const pushLine = (role: Line["role"], text: string) => {
//     setTranscript((prev) => [
//       ...prev,
//       { role, message: text, timestamp: stamp(), final: true },
//     ]);
//   };

//   const flushBuffer = (role: Line["role"], force = false) => {
//     const current = buffersRef.current[role] || "";
//     if (!current.trim()) return;
//     const { completed, remainder } = popCompleteSentences(current);
//     completed.forEach((s) => pushLine(role, s));
//     if (force && remainder.trim()) {
//       pushLine(role, ensureSentenceEnd(remainder));
//       buffersRef.current[role] = "";
//     } else {
//       buffersRef.current[role] = remainder;
//     }
//   };

//   const resetBuffers = () => {
//     buffersRef.current = { "AI Interviewer": "", You: "" };
//     lastSeenRef.current = { "AI Interviewer": "", You: "" };
//     lastRoleRef.current = null;
//   };

//   // ===== Effects =====
//   useEffect(() => {
//     // Load and coerce report_id from localStorage → number
//     const ridRaw = localStorage.getItem("report_id");
//     const ridNum = ridRaw !== null ? Number(ridRaw) : null;
//     setReportId(
//       ridNum !== null && Number.isFinite(ridNum) ? ridNum : null
//     );

//     setJobTitle(localStorage.getItem("job_title"));
//     setCompanyName(localStorage.getItem("company_name"));

//     const vapi = new Vapi(PUBLIC_KEY);
//     vapiRef.current = vapi;

//     vapi.on("call-start", () => setStatus("listening"));
//     vapi.on("speech-start", () => setStatus("speaking"));
//     vapi.on("speech-end", () => {
//       // AI finished talking → flush any remaining AI buffer as complete
//       flushBuffer("AI Interviewer", true);
//       setStatus("thinking");
//     });
//     vapi.on("call-end", () => {
//       // Final flush for both speakers
//       flushBuffer("AI Interviewer", true);
//       flushBuffer("You", true);
//       setStatus("idle");
//       stopCamera();
//     });

//     // Build transcript: buffer partials and only show complete sentences
//     vapi.on("message", (m: VapiMessage) => {
//       if (m.type !== "transcript") return;
//       const role = roleLabel(m.role);
//       const fullText = (m as any).transcript ?? "";

//       // Speaker switch → flush previous role's remainder as a sentence
//       if (lastRoleRef.current && lastRoleRef.current !== role) {
//         flushBuffer(lastRoleRef.current, true);
//       }
//       lastRoleRef.current = role;

//       const lastSeen = lastSeenRef.current[role] || "";
//       const delta =
//         fullText && fullText.startsWith(lastSeen)
//           ? fullText.slice(lastSeen.length)
//           : fullText; // robust if backend resets the string
//       lastSeenRef.current[role] = fullText;

//       // Append delta → try to emit any full sentences
//       buffersRef.current[role] += delta;
//       flushBuffer(role, false); // only emit completed sentences; keep remainder hidden
//     });

//     return () => {
//       try {
//         vapi.stop();
//       } catch {}
//     };
//   }, []);

//   // Timer
//   useEffect(() => {
//     if (status !== "idle") {
//       timerRef.current = setInterval(() => setTimer((p) => p + 1), 1000);
//     } else {
//       if (timerRef.current) clearInterval(timerRef.current);
//       setTimer(0);
//     }
//     return () => {
//       if (timerRef.current) clearInterval(timerRef.current);
//     };
//   }, [status]);

//   // Auto-scroll transcript
//   useEffect(() => {
//     const el = transcriptWrapRef.current;
//     if (!el) return;
//     el.scrollTop = el.scrollHeight;
//   }, [transcript]);

//   // Bind video element
//   useEffect(() => {
//     if (videoRef.current && videoStream && !isVideoOff) {
//       (videoRef.current as HTMLVideoElement).srcObject = videoStream;
//     }
//     if (videoRef.current && (!videoStream || isVideoOff)) {
//       (videoRef.current as HTMLVideoElement).srcObject = null;
//     }
//   }, [videoStream, isVideoOff]);

//   // ===== Media controls =====
//   const startCamera = async () => {
//     // Ensure video is on immediately at start
//     const stream = await navigator.mediaDevices.getUserMedia({
//       audio: true,
//       video: { facingMode: "user" },
//     });
//     // Make sure tracks are enabled (in case previous session disabled them)
//     stream.getVideoTracks().forEach((t) => (t.enabled = true));
//     stream.getAudioTracks().forEach((t) => (t.enabled = true));

//     setIsVideoOff(false); // critical: start with camera ON
//     setVideoStream(stream);

//     if (videoRef.current) {
//       (videoRef.current as HTMLVideoElement).srcObject = stream;
//       try {
//         await (videoRef.current as HTMLVideoElement).play();
//       } catch {}
//     }
//     return stream;
//   };

//   const stopCamera = () => {
//     if (videoStream) {
//       videoStream.getTracks().forEach((t) => t.stop());
//       setVideoStream(null);
//     }
//     if (videoRef.current)
//       (videoRef.current as HTMLVideoElement).srcObject = null;
//   };

//   // ===== Call lifecycle =====
//   const handleStart = async () => {
//     if (!vapiRef.current) return;
//     setIsAnimatingOut(false);
//     setTranscript([]);
//     resetBuffers(); // reset sentence buffers
//     setIsVideoOff(false); // ensure camera is intended ON for new call
//     try {
//       await startCamera(); // request cam + mic and show video immediately
//       await vapiRef.current.start(ASSISTANT_ID, {
//         variableValues: {
//           // send as NUMBER
//           report_id: reportId as number,
//           company_name: companyname ?? undefined,
//           job_title: jobtitle ?? undefined,
//         },
//       });
//     } catch (e) {
//       console.error(e);
//     }
//   };

//   const handleEnd = () => {
//     if (!vapiRef.current) return;
//     setIsAnimatingOut(true);
//     vapiRef.current.stop();
//     // Final flush in case anything remains
//     flushBuffer("AI Interviewer", true);
//     flushBuffer("You", true);
//     stopCamera();
//     setTimeout(() => {
//       setStatus("idle");
//       setIsAnimatingOut(false);
//     }, 250);
//   };

//   const handleRestart = () => {
//     handleEnd();
//     setTimeout(() => handleStart(), 600);
//   };

//   const toggleMute = () => {
//     if (!videoStream) return;
//     const track = videoStream.getAudioTracks()[0];
//     if (!track) return;
//     track.enabled = !track.enabled;
//     setIsMuted(!isMuted);
//   };

//   const toggleVideo = () => {
//     if (!videoStream) return;
//     const track = videoStream.getVideoTracks()[0];
//     if (!track) return;
//     track.enabled = !track.enabled;
//     setIsVideoOff(!isVideoOff);
//   };

//   const agentSpeaking = status === "speaking";
//   const agentListening = status === "listening";
//   const agentThinking = status === "thinking";

//   const formatTime = (seconds: number) => {
//     const mins = Math.floor(seconds / 60);
//     const secs = seconds % 60;
//     return `${mins.toString().padStart(2, "0")}:${secs
//       .toString()
//       .padStart(2, "0")}`;
//   };

//   const getUserInitial = () =>
//     user?.email ? user.email.charAt(0).toUpperCase() : "U";

//   // ===== Render =====
//   return (
//     <main className="h-[100svh] bg-gradient-to-br from-primary/80 via-primary to-primary/80 flex flex-col">
//       {/* Header */}
//       <header className="bg-black/20 backdrop-blur-sm border-b border-white/10 px-4 py-3">
//         <div className="max-w-7xl mx-auto flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
//           <div className="flex items-center gap-4">
//             <h1 className="text-lg font-semibold text-white">AI Interview</h1>
//           </div>
//           <div className="flex items-center gap-3">
//             <div className="bg-black/30 px-3 py-1.5 rounded-lg text-sm font-medium text-white/90 border border-white/20">
//               {/* Coerce number to string only for display */}
//               Meeting ID: {reportId != null ? String(reportId) : "—"}
//             </div>
//             {status !== "idle" && (
//               <div className="bg-red-500/20 px-3 py-1.5 rounded-lg text-sm font-medium text-red-200 border border-red-400/30 flex items-center gap-2">
//                 <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse" />
//                 LIVE {formatTime(timer)}
//               </div>
//             )}
//           </div>
//         </div>
//       </header>

//       <div className="flex-1 min-h-0 flex">
//         {status === "idle" ? (
//           <div className="flex-1 flex flex-col items-center justify-center p-6">
//             <div className="text-center mb-8 max-w-2xl">
//               <h2 className="text-3xl font-semibold text-white mb-4">
//                 Ready to Begin Your Interview?
//               </h2>
//               <p className="text-lg font-medium text-white/80">
//                 Start your professional AI-powered interview session when you're
//                 ready.
//               </p>
//             </div>
//             <Button
//               onClick={handleStart}
//               disabled={!reportId}
//               size="lg"
//               className="text-white px-8 py-3 text-base font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
//             >
//               Start Interview
//             </Button>
//             {!reportId && (
//               <p className="text-sm font-medium text-red-300 mt-4">
//                 Please ensure you have a valid report ID to start the interview.
//               </p>
//             )}
//           </div>
//         ) : (
//           // Live layout
//           <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
//             {/* Video panel */}
//             <div className="relative flex-1 p-2 sm:p-4 order-1 min-h-0">
//               <div
//                 className={`relative w-full h-[calc(100svh-160px)] sm:h-auto sm:aspect-video bg-gray-900 rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 ${
//                   isUserSpeaking
//                     ? "ring-4 ring-green-400 shadow-green-400/20"
//                     : ""
//                 }`}
//               >
//                 {videoStream && !isVideoOff ? (
//                   <video
//                     ref={videoRef}
//                     autoPlay
//                     muted
//                     playsInline
//                     className="w-full h-full object-cover"
//                   />
//                 ) : (
//                   <div className="w-full h-full flex items-center justify-center bg-gray-800">
//                     <div className="text-center">
//                       <div className="w-20 h-20 bg-gray-600 rounded-full flex items-center justify-center mb-3 mx-auto">
//                         <span className="text-2xl text-white">
//                           {getUserInitial()}
//                         </span>
//                       </div>
//                       <p className="text-white text-sm font-medium">
//                         Camera Off
//                       </p>
//                     </div>
//                   </div>
//                 )}

//                 {/* user label */}
//                 <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm px-3 py-1.5 rounded-lg">
//                   <div className="flex items-center gap-2">
//                     <span className="text-white font-medium select-none">
//                       {myLabel}
//                     </span>
//                     {isUserSpeaking && (
//                       <div className="flex gap-1">
//                         <div className="w-1 h-3 bg-green-400 rounded-full animate-pulse" />
//                         <div
//                           className="w-1 h-2 bg-green-400 rounded-full animate-pulse"
//                           style={{ animationDelay: "0.1s" }}
//                         />
//                         <div
//                           className="w-1 h-4 bg-green-400 rounded-full animate-pulse"
//                           style={{ animationDelay: "0.2s" }}
//                         />
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               </div>

//               {/* Agent PiP (hidden on xs) */}
//               <div
//                 className={`hidden sm:block absolute bottom-6 right-6 w-48 h-36 bg-gray-900 rounded-xl overflow-hidden shadow-xl transition-all duration-300 ${
//                   agentSpeaking ? "ring-3 ring-blue-400 shadow-blue-400/20" : ""
//                 }`}
//               >
//                 <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600 relative">
//                   <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
//                     <span className="text-2xl">🤖</span>
//                   </div>
//                   <div className="absolute bottom-2 left-2 bg-black/50 backdrop-blur-sm px-2 py-1 rounded">
//                     <div className="flex items-center gap-1.5">
//                       <span className="text-white text-sm font-medium">
//                         AI Interviewer
//                       </span>
//                       {agentSpeaking && (
//                         <div className="flex gap-0.5">
//                           <div className="w-0.5 h-2 bg-blue-400 rounded-full animate-pulse"></div>
//                           <div
//                             className="w-0.5 h-1.5 bg-blue-400 rounded-full animate-pulse"
//                             style={{ animationDelay: "0.1s" }}
//                           ></div>
//                           <div
//                             className="w-0.5 h-3 bg-blue-400 rounded-full animate-pulse"
//                             style={{ animationDelay: "0.2s" }}
//                           ></div>
//                         </div>
//                       )}
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               {/* Controls – fixed so they’re *always* reachable */}
//               <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50">
//                 <div className="bg-black/50 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2 sm:gap-4 shadow-xl">
//                   <Button
//                     variant="ghost"
//                     size="sm"
//                     onClick={toggleMute}
//                     className={`rounded-full w-10 h-10 p-0 transition-colors ${
//                       isMuted
//                         ? "bg-red-500 hover:bg-red-600 text-white"
//                         : "bg-white/20 hover:bg-white/30 text-white"
//                     }`}
//                   >
//                     {isMuted ? (
//                       <MicOff className="h-4 w-4" />
//                     ) : (
//                       <Mic className="h-4 w-4" />
//                     )}
//                   </Button>

//                   <Button
//                     variant="ghost"
//                     size="sm"
//                     onClick={toggleVideo}
//                     className={`rounded-full w-10 h-10 p-0 transition-colors ${
//                       isVideoOff
//                         ? "bg-red-500 hover:bg-red-600 text-white"
//                         : "bg-white/20 hover:bg-white/30 text-white"
//                     }`}
//                   >
//                     {isVideoOff ? (
//                       <VideoOff className="h-4 w-4" />
//                     ) : (
//                       <Video className="h-4 w-4" />
//                     )}
//                   </Button>

//                   <Button
//                     variant="ghost"
//                     size="sm"
//                     onClick={handleRestart}
//                     className="rounded-full w-10 h-10 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
//                   >
//                     <RotateCcw className="h-4 w-4" />
//                   </Button>

//                   <Button
//                     variant="destructive"
//                     size="sm"
//                     onClick={handleEnd}
//                     className="rounded-full w-10 h-10 p-0"
//                   >
//                     <PhoneOff className="h-4 w-4" />
//                   </Button>

//                   <Sheet>
//                     <SheetTrigger asChild>
//                       <Button
//                         variant="ghost"
//                         size="sm"
//                         className="rounded-full w-10 h-10 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
//                       >
//                         <Settings className="h-4 w-4" />
//                       </Button>
//                     </SheetTrigger>
//                     <SheetContent className="bg-white">
//                       <SheetHeader>
//                         <SheetTitle className="font-semibold text-gray-900">
//                           Session Information
//                         </SheetTitle>
//                       </SheetHeader>
//                       <div className="mt-6 space-y-4">
//                         <div>
//                           <label className="text-sm font-semibold text-gray-700">
//                             Report ID
//                           </label>
//                           <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
//                             {reportId != null ? String(reportId) : "Not set"}
//                           </p>
//                         </div>
//                         <div>
//                           <label className="text-sm font-semibold text-gray-700">
//                             Job Title
//                           </label>
//                           <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
//                             {jobtitle || "Not set"}
//                           </p>
//                         </div>
//                         <div>
//                           <label className="text-sm font-semibold text-gray-700">
//                             Company
//                           </label>
//                           <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
//                             {companyname || "Not set"}
//                           </p>
//                         </div>
//                       </div>
//                     </SheetContent>
//                   </Sheet>
//                 </div>
//               </div>
//             </div>

//             {/* Transcript panel */}
//             <div className="w-full lg:w-80 bg-white/95 backdrop-blur-sm border-t lg:border-t-0 lg:border-l border-white/20 flex flex-col order-2 min-h-0">
//               <div className="p-4 border-b border-gray-200 sticky top-0 bg-white/95 z-10">
//                 <h3 className="font-semibold text-gray-900">Live Transcript</h3>
//                 <p className="text-sm text-gray-600 mt-1">
//                   Real-time conversation transcript
//                 </p>
//               </div>

//               <div
//                 ref={transcriptWrapRef}
//                 className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[unset] min-h-0"
//               >
//                 {transcript.map((entry, index) => (
//                   <div key={index} className="space-y-2">
//                     <div className="flex items-center gap-2">
//                       <span className="font-medium text-gray-900 text-sm">
//                         {entry.role}
//                       </span>
//                       <span className="text-xs text-gray-500">
//                         {entry.timestamp}
//                       </span>
//                     </div>
//                     <div
//                       className={`p-3 rounded-lg text-sm ${
//                         entry.role === "AI Interviewer"
//                           ? "bg-blue-50 text-blue-900"
//                           : "bg-gray-50 text-gray-900"
//                       }`}
//                     >
//                       {entry.message}
//                     </div>
//                   </div>
//                 ))}
//                 {transcript.length === 0 && (
//                   <div className="text-center text-gray-500 mt-8">
//                     <p className="text-sm">
//                       Transcript will appear here once the conversation
//                       starts...
//                     </p>
//                   </div>
//                 )}
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </main>
//   );
// }





// "use client"

// import { useEffect, useRef, useState } from "react"
// import Vapi, { type VapiMessage } from "@vapi-ai/web"
// import DashboardButton from "@/components/DashboardButton"
// import { Button } from "@/components/ui/button"
// import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
// import { LogOut, RotateCcw, PhoneOff, Settings, Mic, MicOff, Video, VideoOff } from "lucide-react"
// import { useAuth } from "@/components/AuthProvider"

// type Status = "idle" | "listening" | "thinking" | "speaking"

// const PUBLIC_KEY = "4b3fb521-9ad5-439a-8224-cdb78e2e78e8"
// const ASSISTANT_ID = "9295e1aa-6e41-4334-9dc4-030954c7274a"

// function usePersistentSpeakingIndicator(active: boolean) {
//   const [isUserSpeaking, setIsUserSpeaking] = useState(false)
//   const audioContextRef = useRef<AudioContext | null>(null)
//   const analyserRef = useRef<AnalyserNode | null>(null)
//   const rafRef = useRef<number | null>(null)
//   const streamRef = useRef<MediaStream | null>(null)

//   useEffect(() => {
//     let isMounted = true

//     if (active && !audioContextRef.current) {
//       navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
//         streamRef.current = stream
//         const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
//         audioContextRef.current = ctx
//         const source = ctx.createMediaStreamSource(stream)
//         const analyser = ctx.createAnalyser()
//         analyser.fftSize = 512
//         source.connect(analyser)
//         analyserRef.current = analyser
//         const dataArray = new Uint8Array(analyser.frequencyBinCount)

//         const detect = () => {
//           analyser.getByteFrequencyData(dataArray)
//           const volume = dataArray.reduce((a, b) => a + b, 0) / dataArray.length
//           if (isMounted) {
//             const isSpeaking = volume > 10
//             setIsUserSpeaking(isSpeaking)
//           }
//           rafRef.current = requestAnimationFrame(detect)
//         }
//         detect()
//       })
//     }

//     if (!active) setIsUserSpeaking(false)

//     return () => {
//       isMounted = false
//       if (audioContextRef.current) {
//         audioContextRef.current.close()
//         audioContextRef.current = null
//       }
//       if (streamRef.current) {
//         streamRef.current.getTracks().forEach((t) => t.stop())
//         streamRef.current = null
//       }
//       if (rafRef.current !== null) {
//         cancelAnimationFrame(rafRef.current)
//       }
//     }
//   }, [active])

//   return isUserSpeaking
// }

// export default function InterviewVoiceDemo() {
//   const [status, setStatus] = useState<Status>("idle")
//   const [reportId, setReportId] = useState<string | null>(null)
//   const [jobtitle, setJobTitle] = useState<string | null>(null)
//   const [companyname, setCompanyName] = useState<string | null>(null)
//   const [isAnimatingOut, setIsAnimatingOut] = useState(false)
//   const [timer, setTimer] = useState(0)
//   const [transcript, setTranscript] = useState<Array<{ role: string; message: string; timestamp: string }>>([])
//   const [videoStream, setVideoStream] = useState<MediaStream | null>(null)
//   const [isMuted, setIsMuted] = useState(false)
//   const [isVideoOff, setIsVideoOff] = useState(false)

//   const vapiRef = useRef<Vapi | null>(null)
//   const timerRef = useRef<NodeJS.Timeout | null>(null)
//   const videoRef = useRef<HTMLVideoElement>(null)
//   const isUserSpeaking = usePersistentSpeakingIndicator(status === "listening")
//   const { user } = useAuth()

//   useEffect(() => {
//     if (videoRef.current && videoStream && !isVideoOff) {
//       ;(videoRef.current as HTMLVideoElement).srcObject = videoStream
//     }
//     if (videoRef.current && (!videoStream || isVideoOff)) {
//       ;(videoRef.current as HTMLVideoElement).srcObject = null
//     }
//   }, [videoStream, isVideoOff])

//   useEffect(() => {
//     if (status !== "idle") {
//       timerRef.current = setInterval(() => {
//         setTimer((prev) => prev + 1)
//       }, 1000)
//     } else {
//       if (timerRef.current) {
//         clearInterval(timerRef.current)
//       }
//       setTimer(0)
//     }

//     return () => {
//       if (timerRef.current) {
//         clearInterval(timerRef.current)
//       }
//     }
//   }, [status])

//   useEffect(() => {
//     setReportId(localStorage.getItem("report_id"))
//     setJobTitle(localStorage.getItem("job_title"))
//     setCompanyName(localStorage.getItem("company_name"))
//     const vapi = new Vapi(PUBLIC_KEY)
//     vapiRef.current = vapi

//     vapi.on("call-start", () => setStatus("listening"))
//     vapi.on("speech-start", () => setStatus("speaking"))
//     vapi.on("speech-end", () => setStatus("thinking"))
//     vapi.on("call-end", () => setStatus("idle"))

//     vapi.on("message", (m: VapiMessage) => {
//       if (m.type === "transcript") {
//         const now = new Date()
//         const timestamp = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
//         setTranscript((prev) => [
//           ...prev,
//           {
//             role: m.role === "assistant" ? "AI Interviewer" : user?.name || user?.email?.split('@')[0] || "You",
//             message: m.transcript,
//             timestamp,
//           },
//         ])
//       }
//     })

//     return () => vapi.stop()
//   }, [])

//   const startCamera = async () => {
//     try {
//       const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true })
//       setVideoStream(stream)
//       if (videoRef.current) {
//         ;(videoRef.current as HTMLVideoElement).srcObject = stream
//       }
//       return stream
//     } catch (error) {
//       setVideoStream(null)
//       if (videoRef.current) (videoRef.current as HTMLVideoElement).srcObject = null
//       throw error
//     }
//   }

//   const stopCamera = () => {
//     if (videoStream) {
//       videoStream.getTracks().forEach((track) => track.stop())
//       setVideoStream(null)
//     }
//     if (videoRef.current) {
//       ;(videoRef.current as HTMLVideoElement).srcObject = null
//     }
//   }

//   const handleStart = async () => {
//     if (!vapiRef.current) return
//     setIsAnimatingOut(false)
//     setTranscript([])

//     try {
//       await startCamera()
//       await vapiRef.current.start(ASSISTANT_ID, {
//         variableValues: {
//           report_id: reportId,
//           company_name: companyname,
//           job_title: jobtitle,
//         },
//       })
//     } catch (error) {
//       console.error("Error accessing media devices:", error)
//     }
//   }

//   const handleEnd = () => {
//     if (vapiRef.current) {
//       setIsAnimatingOut(true)
//       vapiRef.current.stop()
//       stopCamera()
//       setTimeout(() => {
//         setStatus("idle")
//         setIsAnimatingOut(false)
//       }, 300)
//     }
//   }

//   const handleRestart = () => {
//     handleEnd()
//     setTimeout(() => handleStart(), 1000)
//   }

//   const toggleMute = () => {
//     if (videoStream) {
//       const audioTrack = videoStream.getAudioTracks()[0]
//       if (audioTrack) {
//         audioTrack.enabled = !audioTrack.enabled
//         setIsMuted(!audioTrack.enabled)
//       }
//     }
//   }

//   const toggleVideo = () => {
//     if (videoStream) {
//       const videoTrack = videoStream.getVideoTracks()[0]
//       if (videoTrack) {
//         videoTrack.enabled = !videoTrack.enabled
//         setIsVideoOff(!videoTrack.enabled)
//       }
//     }
//   }

//   const agentSpeaking = status === "speaking"
//   const agentListening = status === "listening"
//   const agentThinking = status === "thinking"

//   const formatTime = (seconds: number) => {
//     const mins = Math.floor(seconds / 60)
//     const secs = seconds % 60
//     return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
//   }

//   const getUserInitial = () => {
//     if (user?.email) {
//       return user.email.charAt(0).toUpperCase()
//     }
//     return "U"
//   }

// return (
//   <main className="min-h-[80vh] bg-gradient-to-br from-primary/80 via-primary to-primary/80 flex flex-col">
//     {/* Header */}
//     <header className="bg-black/20 backdrop-blur-sm border-b border-white/10 px-4 py-3">
//       <div className="max-w-7xl mx-auto flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
//         {/* left */}
//         <div className="flex items-center gap-4">
//           <h1 className="text-lg font-semibold text-white">AI Interview</h1>
//         </div>

//         {/* right: Meeting ID + LIVE */}
//         <div className="flex items-center gap-3">
//           <div className="bg-black/30 px-3 py-1.5 rounded-lg text-sm font-medium text-white/90 border border-white/20">
//             Meeting ID: {reportId || "—"}
//           </div>
//           {status !== "idle" && (
//             <div className="bg-red-500/20 px-3 py-1.5 rounded-lg text-sm font-medium text-red-200 border border-red-400/30 flex items-center gap-2">
//               <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse" />
//               LIVE {formatTime(timer)}
//             </div>
//           )}
//         </div>
//       </div>
//     </header>

//     <div className="flex-1 flex">
//       {status === "idle" ? (
//         <div className="flex-1 flex flex-col items-center justify-center p-8">
//           <div className="text-center mb-8 max-w-2xl">
//             <h2 className="text-3xl font-semibold text-white mb-4">
//               Ready to Begin Your Interview?
//             </h2>
//             <p className="text-lg font-medium text-white/80">
//               Start your professional AI-powered interview session when you're ready.
//             </p>
//           </div>
//           <Button
//             onClick={handleStart}
//             disabled={!reportId}
//             size="lg"
//             className="text-white px-8 py-3 text-base font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
//           >
//             Start Interview
//           </Button>
//           {!reportId && (
//             <p className="text-sm font-medium text-red-300 mt-4">
//               Please ensure you have a valid report ID to start the interview.
//             </p>
//           )}
//         </div>
//       ) : (
//         // Live layout
//         <div className="flex-1 flex flex-col lg:flex-row">
//           {/* Video panel */}
//           <div className="flex-1 relative p-4 order-1">
// <div
//   className={`relative w-full aspect-video bg-gray-900 rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 ${
//     isUserSpeaking ? "ring-4 ring-green-400 shadow-green-400/20" : ""
//   }`}
// >
//   {videoStream && !isVideoOff ? (
//     <video
//       ref={videoRef}
//       autoPlay
//       muted
//       playsInline
//       className="w-full h-full object-cover"
//     />
//   ) : (
//     <div className="w-full h-full flex items-center justify-center bg-gray-800">
//       <div className="text-center">
//         <div className="w-20 h-20 bg-gray-600 rounded-full flex items-center justify-center mb-3 mx-auto">
//           <span className="text-2xl text-white">{getUserInitial()}</span>
//         </div>
//         <p className="text-white text-sm font-medium">Camera Off</p>
//       </div>
//     </div>
//   )}

//               {/* user label */}
//               <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm px-3 py-1.5 rounded-lg">
//                 <div className="flex items-center gap-2">
//                   <span className="text-white font-medium select-none">{user?.name || user?.email?.split('@')[0] || "You"}</span>
//                   {isUserSpeaking && (
//                     <div className="flex gap-1">
//                       <div className="w-1 h-3 bg-green-400 rounded-full animate-pulse" />
//                       <div
//                         className="w-1 h-2 bg-green-400 rounded-full animate-pulse"
//                         style={{ animationDelay: "0.1s" }}
//                       />
//                       <div
//                         className="w-1 h-4 bg-green-400 rounded-full animate-pulse"
//                         style={{ animationDelay: "0.2s" }}
//                       />
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>

//             {/* Agent PiP */}
//             {/* <div
//               className={`absolute bottom-6 right-6 w-48 h-36 bg-gray-900 rounded-xl overflow-hidden shadow-xl transition-all duration-300 ${
//                 agentSpeaking ? "ring-3 ring-blue-400 shadow-blue-400/20" : ""
//               }`}
//             >
//               <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600 relative">
//                 <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
//                   <span className="text-2xl">🤖</span>
//                 </div>

//                 <div className="absolute bottom-2 left-2 bg-black/50 backdrop-blur-sm px-2 py-1 rounded">
//                   <div className="flex items-center gap-1.5">
//                     <span className="text-white text-sm font-medium select-none">Mike</span>
//                     {agentSpeaking && (
//                       <div className="flex gap-0.5">
//                         <div className="w-0.5 h-2 bg-blue-400 rounded-full animate-pulse" />
//                         <div
//                           className="w-0.5 h-1.5 bg-blue-400 rounded-full animate-pulse"
//                           style={{ animationDelay: "0.1s" }}
//                         />
//                         <div
//                           className="w-0.5 h-3 bg-blue-400 rounded-full animate-pulse"
//                           style={{ animationDelay: "0.2s" }}
//                         />
//                       </div>
//                     )}
//                   </div>
//                 </div>

//                 {(agentListening || agentThinking) && (
//                   <div className="absolute top-2 right-2">
//                     {agentListening && (
//                       <div className="bg-green-500 text-white px-2 py-1 rounded text-xs font-medium">
//                         Listening
//                       </div>
//                     )}
//                     {agentThinking && (
//                       <div className="bg-yellow-500 text-white px-2 py-1 rounded text-xs font-medium flex items-center gap-1">
//                         <div className="w-1 h-1 bg-white rounded-full animate-bounce" />
//                         Thinking
//                       </div>
//                     )}
//                   </div>
//                 )}
//               </div>
//             </div> */}
//             {/* Agent PiP — hidden on mobile, visible from `sm:` and above */}
// <div
//   className={`hidden sm:block absolute bottom-6 right-6 w-48 h-36 bg-gray-900 rounded-xl overflow-hidden shadow-xl transition-all duration-300 ${
//     agentSpeaking ? "ring-3 ring-blue-400 shadow-blue-400/20" : ""
//   }`}
// >
//   <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600 relative">
//     <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
//       <span className="text-2xl">🤖</span>
//     </div>

//     <div className="absolute bottom-2 left-2 bg-black/50 backdrop-blur-sm px-2 py-1 rounded">
//       <div className="flex items-center gap-1.5">
//         <span className="text-white text-sm font-medium">AI Interviewer</span>
//         {agentSpeaking && (
//           <div className="flex gap-0.5">
//             <div className="w-0.5 h-2 bg-blue-400 rounded-full animate-pulse"></div>
//             <div
//               className="w-0.5 h-1.5 bg-blue-400 rounded-full animate-pulse"
//               style={{ animationDelay: "0.1s" }}
//             ></div>
//             <div
//               className="w-0.5 h-3 bg-blue-400 rounded-full animate-pulse"
//               style={{ animationDelay: "0.2s" }}
//             ></div>
//           </div>
//         )}
//       </div>
//     </div>
//   </div>
// </div>


//             {/* Controls */}
//             {/* <div className="absolute bottom-6 left-1/2 -translate-x-1/2 px-3 sm:px-0">
//               <div className="bg-black/50 backdrop-blur-sm rounded-full px-4 sm:px-6 py-3 flex items-center gap-3 sm:gap-4 shadow-xl">
//                 <Button
//                   variant="ghost"
//                   size="sm"
//                   onClick={toggleMute}
//                   className={`rounded-full w-12 h-12 p-0 transition-colors ${
//                     isMuted ? "bg-red-500 hover:bg-red-600 text-white" : "bg-white/20 hover:bg-white/30 text-white"
//                   }`}
//                 >
//                   {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
//                 </Button>

//                 <Button
//                   variant="ghost"
//                   size="sm"
//                   onClick={toggleVideo}
//                   className={`rounded-full w-12 h-12 p-0 transition-colors ${
//                     isVideoOff ? "bg-red-500 hover:bg-red-600 text-white" : "bg-white/20 hover:bg-white/30 text-white"
//                   }`}
//                 >
//                   {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
//                 </Button>

//                 <Button
//                   variant="ghost"
//                   size="sm"
//                   onClick={handleRestart}
//                   className="rounded-full w-12 h-12 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
//                 >
//                   <RotateCcw className="h-5 w-5" />
//                 </Button>

//                 <Button variant="destructive" size="sm" onClick={handleEnd} className="rounded-full w-12 h-12 p-0">
//                   <PhoneOff className="h-5 w-5" />
//                 </Button>

//                 <Sheet>
//                   <SheetTrigger asChild>
//                     <Button
//                       variant="ghost"
//                       size="sm"
//                       className="rounded-full w-12 h-12 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
//                     >
//                       <Settings className="h-5 w-5" />
//                     </Button>
//                   </SheetTrigger>
//                   <SheetContent className="bg-white">
//                     <SheetHeader>
//                       <SheetTitle className="font-semibold text-gray-900">Session Information</SheetTitle>
//                     </SheetHeader>
//                     <div className="mt-6 space-y-4">
//                       <div>
//                         <label className="text-sm font-semibold text-gray-700">Report ID</label>
//                         <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
//                           {reportId || "Not set"}
//                         </p>
//                       </div>
//                       <div>
//                         <label className="text-sm font-semibold text-gray-700">Job Title</label>
//                         <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
//                           {jobtitle || "Not set"}
//                         </p>
//                       </div>
//                       <div>
//                         <label className="text-sm font-semibold text-gray-700">Company</label>
//                         <p className="text-sm font-medium text-gray-900 bg-gray-50 p-3 rounded-lg mt-1 border border-gray-200">
//                           {companyname || "Not set"}
//                         </p>
//                       </div>
//                     </div>
//                   </SheetContent>
//                 </Sheet>
//               </div>
//             </div> */}


//             {/* Controls bar */}
// <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-2 sm:px-0">
//   <div className="bg-black/50 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2 sm:gap-4 shadow-xl">
//     <Button
//       variant="ghost"
//       size="sm"
//       onClick={toggleMute}
//       className={`rounded-full w-10 h-10 p-0 transition-colors ${
//         isMuted
//           ? "bg-red-500 hover:bg-red-600 text-white"
//           : "bg-white/20 hover:bg-white/30 text-white"
//       }`}
//     >
//       {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
//     </Button>

//     <Button
//       variant="ghost"
//       size="sm"
//       onClick={toggleVideo}
//       className={`rounded-full w-10 h-10 p-0 transition-colors ${
//         isVideoOff
//           ? "bg-red-500 hover:bg-red-600 text-white"
//           : "bg-white/20 hover:bg-white/30 text-white"
//       }`}
//     >
//       {isVideoOff ? <VideoOff className="h-4 w-4" /> : <Video className="h-4 w-4" />}
//     </Button>

//     <Button
//       variant="ghost"
//       size="sm"
//       onClick={handleRestart}
//       className="rounded-full w-10 h-10 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
//     >
//       <RotateCcw className="h-4 w-4" />
//     </Button>

//     <Button
//       variant="destructive"
//       size="sm"
//       onClick={handleEnd}
//       className="rounded-full w-10 h-10 p-0"
//     >
//       <PhoneOff className="h-4 w-4" />
//     </Button>

//     <Sheet>
//       <SheetTrigger asChild>
//         <Button
//           variant="ghost"
//           size="sm"
//           className="rounded-full w-10 h-10 p-0 bg-white/20 hover:bg-white/30 text-white transition-colors"
//         >
//           <Settings className="h-4 w-4" />
//         </Button>
//       </SheetTrigger>
//       {/* Session Info Sheet Content */}
//     </Sheet>
//   </div>
// </div>

//           </div>

//           {/* Transcript panel */}
//           <div className="w-full lg:w-80 bg-white/95 backdrop-blur-sm border-t lg:border-t-0 lg:border-l border-white/20 flex flex-col order-2">
//             <div className="p-4 border-b border-gray-200 sticky top-0 bg-white/95 z-10">
//               <h3 className="font-semibold text-gray-900">Live Transcript</h3>
//               <p className="text-sm text-gray-600 mt-1">Real-time conversation transcript</p>
//             </div>

//             <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[calc(100vh-260px)] lg:max-h-[calc(100vh-130px)]">
//               {transcript.map((entry, index) => (
//                 <div key={index} className="space-y-2">
//                   <div className="flex items-center gap-2">
//                     <span className="font-medium text-gray-900 text-sm">{entry.role}</span>
//                     <span className="text-xs text-gray-500">{entry.timestamp}</span>
//                   </div>
//                   <div
//                     className={`p-3 rounded-lg text-sm ${
//                       entry.role === "AI Interviewer" ? "bg-blue-50 text-blue-900" : "bg-gray-50 text-gray-900"
//                     }`}
//                   >
//                     {entry.message}
//                   </div>
//                 </div>
//               ))}

//               {transcript.length === 0 && (
//                 <div className="text-center text-gray-500 mt-8">
//                   <p className="text-sm">
//                     Transcript will appear here once the conversation starts...
//                   </p>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   </main>
// )

// }
