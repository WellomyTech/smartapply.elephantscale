export const NAV_ITEMS = [
  { label: "Logout", href: "https://smartapply.elephantscale.com", external: true }
]
